
- Before entering any key commands make sure you click the animation window, otherwise the keys will not register
- There are a few different key commands to give:
    * Y, used to set the experimental condition to A (which is mirroring).
    * N, used to set the experimental condition to B (which is random movement) 
    * ENTER, press enter after pressing y or n to start the experiment with the calibration.
        -- also to confirm that the participant is done with the description. Makes the simulation go to the next image.
    * Z or X, to run the experiment (without calibration) in condition A or B respectively
     F, to abort/end/finish the simulation once Nao is not speaking (anymore)  
  ** 0-9, to change the next image that'll appear to the digit key pressed (who knows might come in useful**